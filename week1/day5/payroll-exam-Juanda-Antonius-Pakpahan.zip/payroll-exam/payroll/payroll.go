package payroll

import (
	"fmt"
	"payroll-exam/employee"
	"payroll-exam/salarymatrix"
	"strconv"
	"time"
)

// STRUCT
// Payroll → IdPayroll, BasictSalary, PayCut, AdditionalSalary, Employee employee

// Task No 3
// Fitur Tambah Payroll dengan inputan berupa pegawai,
// jumlah hari masuk, jumlah hari tidak masuk yang nanti
// akan diproses menjadi gaji karyawan tersebut

type PayRoll struct {
	IdPayRool        string
	BasicSalary      float64
	Puycut           float64
	AdditionalSalary float64
	Priod            string
	Total            float64
	Employee         employee.Employee
}
type ShowPayRoll struct {
	IdPayRool        string
	BasicSalary      float64
	Puycut           float64
	AdditionalSalary float64
	Priod            string
	Total            float64
}

type PayRollList struct {
	SalaryMatrix salarymatrix.SalaryMatrixInterface
	Employee     employee.EmployeeInterface
	PayRolls     []PayRoll
}

type PayRollInterface interface {
	Add(employId string, hadir float64, absen float64)
	ShowPayrollById(employId string)
	IsPayroll(emploId string, priod string) bool
}

func NewPayroll(salarymatris salarymatrix.SalaryMatrixInterface, employee employee.EmployeeInterface) PayRollInterface {
	return &PayRollList{SalaryMatrix: salarymatris, Employee: employee}
}

func (p *PayRollList) IsPayroll(emploId string, date string) bool {
	for _, v := range p.PayRolls {
		if v.Priod == date && v.Employee.IdEmployee == emploId {
			return true
		}
	}
	return false
}
func (p *PayRollList) Add(employId string, hadir float64, absen float64) {
	idPayroll := "payroll-" + strconv.Itoa(len(p.PayRolls))
	year, month, _ := time.Now().Date()
	priod := fmt.Sprintf("%v-%v", month, year)

	employee := p.Employee.FindEmplById(employId)
	salarymatrix := p.SalaryMatrix.FindByGrade(employee.Grade)

	if isPeriod := p.IsPayroll(employee.IdEmployee, priod); isPeriod {
		fmt.Println(employee.NameEmployee, "sudah peyroll untuk bulan", month, year)
		return
	}

	var addHeadofFamily float64

	if employee.Gender == "L" && employee.IsMarried == true {
		addHeadofFamily = salarymatrix.HeadOfFamily
	}

	newPayroll := PayRoll{
		IdPayRool:        idPayroll,
		BasicSalary:      salarymatrix.BasicSalary,
		Puycut:           absen * salarymatrix.PayCut,
		AdditionalSalary: hadir*salarymatrix.Allowance + addHeadofFamily,
		Priod:            priod,
		Total:            (salarymatrix.BasicSalary - absen*salarymatrix.PayCut + hadir*salarymatrix.Allowance + addHeadofFamily),
		Employee:         employee,
	}

	p.PayRolls = append(p.PayRolls, newPayroll)
}

type ShowPay struct {
	Employee employee.Employee
	PayRoll  []ShowPayRoll
}

func (p *PayRollList) ShowPayrollById(emploId string) {
	payrolls := []ShowPayRoll{}
	showPayroll := ShowPay{}
	employ := employee.Employee{}

	for _, v := range p.PayRolls {

		if v.Employee.IdEmployee == emploId {
			if employ == (employee.Employee{}) {
				employ = v.Employee
			}
			payroll := ShowPayRoll{
				IdPayRool:        v.IdPayRool,
				BasicSalary:      v.BasicSalary,
				Puycut:           v.Puycut,
				AdditionalSalary: v.AdditionalSalary,
				Priod:            v.Priod,
				Total:            v.Total,
			}
			payrolls = append(payrolls, payroll)
		}
	}

	showPayroll.PayRoll = payrolls
	showPayroll.Employee = employ

	fmt.Println(emploId, ":", showPayroll)

}
